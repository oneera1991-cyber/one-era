
const cartKey = "oneEraCart";
function getCart(){ try{return JSON.parse(localStorage.getItem(cartKey)||"[]")}catch(e){return[]}}
function saveCart(c){localStorage.setItem(cartKey,JSON.stringify(c)); updateCartCount()}
function updateCartCount(){
  const n=getCart().reduce((s,i)=>s+i.qty,0);
  document.querySelectorAll("[data-cart-count]").forEach(el=>el.textContent=n);
}
function addToCart(name,price){
  const c=getCart(); const found=c.find(i=>i.name===name);
  if(found) found.qty++; else c.push({name,price,qty:1});
  saveCart(c); alert(name+" added to your ritual.");
}
function renderCart(){
  const wrap=document.querySelector("[data-cart]");
  if(!wrap)return;
  const c=getCart();
  if(!c.length){wrap.innerHTML='<p>Your bag is empty.</p>';return}
  let total=0;
  wrap.innerHTML=c.map((i,idx)=>{
    total+=i.price*i.qty;
    return `<div class="order-line"><span>${i.name} × ${i.qty}</span><span>£${(i.price*i.qty).toFixed(2)}</span></div>`
  }).join("")+`<div class="order-line total"><span>Total</span><span>£${total.toFixed(2)}</span></div>
  <a class="btn btn-dark" href="checkout.html">Proceed to checkout</a>`;
}
document.addEventListener("DOMContentLoaded",()=>{updateCartCount();renderCart()});
