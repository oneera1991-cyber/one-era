/* ONE ERA Orders — shared test order storage */
(function(){"use strict";const ORDER_KEY="oneera_test_order";
function getOrder(){try{let d=localStorage.getItem(ORDER_KEY);return d?JSON.parse(d):null}catch(e){return null}}
function saveOrder(o){if(!o)return null;localStorage.setItem(ORDER_KEY,JSON.stringify(o));return o}
function updateOrderStatus(s){let o=getOrder();if(!o)return null;o.status=s;o.updated_at=new Date().toISOString();return saveOrder(o)}
function updatePaymentStatus(s){let o=getOrder();if(!o)return null;o.payment_status=s;o.updated_at=new Date().toISOString();if(s==="paid")o.status="paid";return saveOrder(o)}
function updateFulfillmentStatus(s){let o=getOrder();if(!o)return null;o.fulfillment_status=s;o.updated_at=new Date().toISOString();return saveOrder(o)}
function clearOrder(){localStorage.removeItem(ORDER_KEY)}
window.ONEERA_ORDERS={getOrder,saveOrder,updateOrderStatus,updatePaymentStatus,updateFulfillmentStatus,clearOrder,ORDER_KEY};console.log("ONE ERA Orders: READY")})();
