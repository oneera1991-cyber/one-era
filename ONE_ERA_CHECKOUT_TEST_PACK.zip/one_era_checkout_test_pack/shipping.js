/* ONE ERA Shipping — TEST MODE */
(function(){"use strict";let config=null;const FALLBACK={test_mode:true,fulfillment:{provider:"CJdropshipping"},services:[{id:"standard",name:"Standard Delivery"}],test_rates_thb:{TH:60,US:420,GB:520,HK:300,AU:500,ID:280,SG:280}};
async function loadShippingConfig(){try{let r=await fetch("shipping.json",{cache:"no-store"});if(!r.ok)throw Error();config=await r.json()}catch(e){config=FALLBACK}return config}
function country(){return window.ONEERA_COMMERCE?.getCountry?.()||localStorage.getItem("oneera_country")||"TH"}
function getRateTHB(c){return Number(config?.test_rates_thb?.[c]??60)}
function getService(){return config?.services?.[0]||{id:"standard",name:"Standard Delivery"}}
function render(){let c=country();document.querySelectorAll("[data-shipping-country]").forEach(e=>e.textContent=c);document.querySelectorAll("[data-fulfillment-provider]").forEach(e=>e.textContent=config?.fulfillment?.provider||"CJdropshipping");document.querySelectorAll("[data-shipping-rate]").forEach(e=>e.textContent=`${getRateTHB(c)} THB (TEST)`);document.querySelectorAll("[data-shipping-status]").forEach(e=>e.textContent="Test shipping rate. Live rate will be connected before launch.")}
window.ONEERA_SHIPPING={loadShippingConfig,getRateTHB,getService,get config(){return config}};document.addEventListener("DOMContentLoaded",async()=>{await loadShippingConfig();render();document.addEventListener("oneera:countrychange",render)})})();
