ONE ERA CHECKOUT TEST PACK

Replace/add these files in the GitHub Pages root:
checkout.html
commerce.js
commerce.json
shipping.js
shipping.json
payment.js
payment.json
orders.js
fulfillment.js

TEST MODE ONLY. No live payment. No live CJ order.
Shared order key: oneera_test_order
Fulfillment key: oneera_fulfillment
Green Fluorite CJ SKU: CJZS237829401AZ

Expected flow:
SHOP -> CART -> CHECKOUT -> CREATE TEST ORDER -> ORDER STORAGE -> FULFILLMENT MAPPING -> CJ TEST PAYLOAD
