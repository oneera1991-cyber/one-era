/* ONE ERA Commerce — single country/currency source */
(function(){"use strict";
const KEY="oneera_country";let config=null;
const FALLBACK={default_country:"TH",supported_countries:[
{code:"TH",name:"Thailand",flag:"🇹🇭",currency:"THB",symbol:"฿",locale:"th-TH"},{code:"US",name:"United States",flag:"🇺🇸",currency:"USD",symbol:"$",locale:"en-US"},{code:"GB",name:"United Kingdom",flag:"🇬🇧",currency:"GBP",symbol:"£",locale:"en-GB"},{code:"HK",name:"Hong Kong",flag:"🇭🇰",currency:"HKD",symbol:"HK$",locale:"en-HK"},{code:"AU",name:"Australia",flag:"🇦🇺",currency:"AUD",symbol:"A$",locale:"en-AU"},{code:"ID",name:"Indonesia",flag:"🇮🇩",currency:"IDR",symbol:"Rp",locale:"id-ID"},{code:"SG",name:"Singapore",flag:"🇸🇬",currency:"SGD",symbol:"S$",locale:"en-SG"}]};
async function loadConfig(){try{let r=await fetch("commerce.json",{cache:"no-store"});if(!r.ok)throw Error();config=await r.json()}catch(e){config=FALLBACK}return config}
function getCountryByCode(c){return config?.supported_countries?.find(x=>x.code===c)||null}
function getCountry(){let s=localStorage.getItem(KEY);return getCountryByCode(s)?s:(config?.default_country||"TH")}
function setCountry(c){if(!getCountryByCode(c))return false;localStorage.setItem(KEY,c);document.dispatchEvent(new CustomEvent("oneera:countrychange",{detail:getCountryByCode(c)}));updateUI();return true}
function updateUI(){let c=getCountryByCode(getCountry());if(!c)return;document.querySelectorAll("[data-country-label]").forEach(e=>e.textContent=`${c.flag} ${c.name}`);document.querySelectorAll("[data-country-code]").forEach(e=>e.textContent=c.code);document.querySelectorAll("[data-currency-code]").forEach(e=>e.textContent=c.currency);document.querySelectorAll("[data-currency-symbol]").forEach(e=>e.textContent=c.symbol);document.querySelectorAll("[data-country-select]").forEach(e=>e.value=c.code)}
function money(a){let c=getCountryByCode(getCountry());return c?new Intl.NumberFormat(c.locale,{style:"currency",currency:c.currency,maximumFractionDigits:c.currency==="IDR"?0:2}).format(Number(a)||0):String(a||0)}
window.ONEERA_COMMERCE={loadConfig,getCountry,setCountry,money,getCountryByCode,get config(){return config}};
document.addEventListener("DOMContentLoaded",async()=>{await loadConfig();document.querySelectorAll("[data-country-select]").forEach(s=>s.addEventListener("change",e=>setCountry(e.target.value)));updateUI()})})();
